﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 23 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World !");
            Console.Read();
        }
    }
}
