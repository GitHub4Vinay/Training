﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMI_Cal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            double ht, wt, bmi;
            ht = Convert.ToDouble(textBox1.Text);
            wt = Convert.ToDouble(textBox2.Text);

            if (radioButton1.Checked)
            {
                bmi = wt / (ht * ht);
                label3.Text = Convert.ToString(string.Format("BMI: {0:0.000}", bmi));
            }
            else
            {
                bmi = (wt / (ht * ht)) * 703;
                label3.Text = Convert.ToString(string.Format("BMI: {0:0.000}", bmi));
            }
        }
    }
}
