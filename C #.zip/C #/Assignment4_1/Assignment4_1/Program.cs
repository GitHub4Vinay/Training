﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double KM;
            int count;
            Console.WriteLine("Miles\t\tKilometers");
            for (count = 1; count <= 100; count++)
            {
                KM = count * 1.609;
                Console.WriteLine("{0}\t\t{1:F4}",count,KM);
                
            }
            Console.Read();

        }
    }
}
