﻿
// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 08 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[101];
            int number;
            Console.WriteLine("Enter integers between 1 and 100.");
            do
            {
                Console.Write("Enter an integer (0 to quit): ");
                number = Convert.ToInt32(Console.ReadLine());
                array[number]++;
            } while (number != 0);
            Console.WriteLine();
            for (int i = 1; i < 101; i++)
            {
                if (array[i] > 0)
                {
                    Console.WriteLine("{0} occurs {1} times", i, array[i]);
                }
            }
            Console.Read();
        }
    }
}
