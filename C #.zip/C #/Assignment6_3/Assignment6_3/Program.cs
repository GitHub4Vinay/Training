﻿
// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 08 June 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Random genenator = new Random();
            int[] array = new int[10];
            for (int i = 0; i < 100; i++)
            {
                array[genenator.Next(0, 10)]++;
            }
            Console.WriteLine("Count\tDigit");
            for (int j = 0; j < 10; j++)
            {
                if (array[j] > 0)
                {
                    Console.WriteLine("{0}\t{1}s", array[j], j);
                }
            }
            Console.Read();
        }
    }
}
