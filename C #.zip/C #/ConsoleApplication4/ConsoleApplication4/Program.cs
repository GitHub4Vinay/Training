﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 23 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            Double weight, height,BMI ;
            Console.WriteLine("Enter the weight in Kilograms");
            weight=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the height in Meters");
            height = Convert.ToDouble(Console.ReadLine());
            BMI = weight /Math.Pow(height,2);
            Console.WriteLine("BMI is {0:F4}", BMI);
            Console.ReadLine();
        }
    }
}
