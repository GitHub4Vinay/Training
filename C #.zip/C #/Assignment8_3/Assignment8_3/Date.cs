﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 20 June 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_3
{
    class Date
    {
        public int Day { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }

        public Date(int month, int day, int year)
        {
            Month = month;
            Day = day;
            Year = year;
        }

        public void DisplayDate()
        {
            Console.WriteLine("{0:D2}/{1:D2}/{2:D2}", Month, Day, Year);
        }
    }
}
