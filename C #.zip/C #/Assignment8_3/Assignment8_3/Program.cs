﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Date Test");
            Date date = new Date(06, 20, 2016);
            date.DisplayDate();
            Console.Read();
        }
    }
}
