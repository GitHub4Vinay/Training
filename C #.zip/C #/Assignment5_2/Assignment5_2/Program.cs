﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 07 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double investmentAmount = 0.0, annualInterestRate = 0.0;
            int years = 0;
            FutureInvestmentAmount(investmentAmount, annualInterestRate, years);
            Console.Read();
        }
        public static double FutureInvestmentAmount(double investmentAmount, double annualInterestrate, int years)
            {
                
                double annualInterestRate, futureInvestmentValue = 0.0, monthlyInterestRate;
                int numberOfYears;
                Console.Write("Enter Investment Amount: ");
                investmentAmount = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter annual percentage rate: ");
                annualInterestRate = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Years\t\tFuture Value");
                for (numberOfYears = 1; numberOfYears <= 30; numberOfYears++)
                {
                    monthlyInterestRate = annualInterestRate / 1200;
                    futureInvestmentValue = investmentAmount * Math.Pow(1 + monthlyInterestRate, numberOfYears * 12);
                    Console.WriteLine(numberOfYears + "\t\t" + "{0:C}", futureInvestmentValue);
                }
                return futureInvestmentValue;
            
        }
    }
}
