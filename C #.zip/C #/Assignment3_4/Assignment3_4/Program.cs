﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Random generator = new Random();
            int randomNumber = generator.Next(0,12);
           // Console.WriteLine(randomNumber);

            switch (randomNumber)
            { 
                case 0:
                    Console.WriteLine("January");
                    break;
                case 1:
                    Console.WriteLine("February");
                    break;
                case 2:
                    Console.WriteLine("March");
                    break;
                case 3:
                    Console.WriteLine("April");
                    break;
                case 4:
                    Console.WriteLine("May");
                    break;
                case 5:
                    Console.WriteLine("June");
                    break;
                case 6:
                    Console.WriteLine("July");
                    break;
                case 7:
                    Console.WriteLine("August");
                    break;
                case 8:
                    Console.WriteLine("September");
                    break;
                case 9:
                    Console.WriteLine("October");
                    break;
                case 10:
                    Console.WriteLine("November");
                    break;
                case 11:
                    Console.WriteLine("December");
                    break;
               

            }

            Console.Read();
        }
    }
}
