﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 07 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            PrintMatrix(i);
            Console.Read();
        }
            public static void PrintMatrix(int i)
            {
                
                Console.Write("Enter a positive integer: ");
                int j = int.Parse(Console.ReadLine());
                int row;
                int column;
                Random rand = new Random();

                for (row = 1; row <= j; row++)
                {
                    for (column = row; column <= row + j - 1;)
                    {
                        Console.Write(rand.Next(0, 2) + " ");
                        column++;
                    }
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
        
    }
}
