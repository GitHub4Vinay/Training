﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6_2
{
    class Program
    {
        static void Main(string[] args)
        {

            int i, j, k, count = 0;
            int[] array = new int[100];
            int[] print = new int[100];
            for (i = 1; i < 100; i++)
            {
                Console.WriteLine("Enter an integer (0 to quit):");
                array[i] = Convert.ToInt32(Console.ReadLine());
                if (array[i] == 0)
                {
                    break;
                }
            }
            for (j = 0; j < i; j++)
            {
                if (array[j] != ' ')
                {
                    count = 0;
                    for (k = 0; k < i; k++)
                    {
                        if ((array[j] == array[k]) && (print[j] != array[k]))
                        {
                            count = count + 1;
                        }
                    }
                    print[j] = array[j];
                    if (count != 0)
                    {
                        Console.WriteLine(array[j] + "occurs" + count + "times");
                    }
                }
                Console.Read();
            }
        }
    }
}
