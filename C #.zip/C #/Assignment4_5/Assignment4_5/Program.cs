﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Double Pi = 0;
            int i ;
            Console.WriteLine("Iterations\tApproximation");
            for (i = 1; i <= 100000; i++)
            {
                Pi += (Double)(Math.Pow(-1, i + 1)) / ((2 * i) - 1);
                if (i % 10000 == 0)
                {
                    Console.WriteLine("{0}\t\t{1:F14}", i, Pi * 4);
                }
            }
                Console.Read();
            }
        }
    
}
