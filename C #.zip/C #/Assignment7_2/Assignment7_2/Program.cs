﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 15 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentence = "";
            SentList = new List<string>();
            Console.WriteLine("Please enter a Sentence:");
            sentence = Console.ReadLine();
            SentList = sentence.ToLower().Split().Distinct().ToList();
            Console.WriteLine("\n\nDistinct words in the Sentence");
            var ExtrWords = from word in SentList
                        orderby word
                        select word;
            foreach (var X in ExtrWords)
                Console.WriteLine(X);
            Console.WriteLine("\n\nWords without Duplicates :");
            SentList = sentence.ToLower().Split().ToList();
            var ExtrWords1 = from word in SentList
                         let duplicate = findDuplicates(word)
                         where duplicate.Equals(false)
                         select word;
            foreach (var X in ExtrWords1)
                Console.WriteLine(X);
            Console.Read();
        }
            public static List<string> SentList;
            public static bool findDuplicates(string word)
            {
                bool isDuplicate = false;
                int numOfDuplicates = 0;
                for (int i = 0; i < SentList.Count; i++)
                {
                    if (SentList[i].Equals(word))
                        numOfDuplicates++;
                }
                if (numOfDuplicates > 1)
                    isDuplicate = true;
                return isDuplicate;

             }
    
        
    }
}
