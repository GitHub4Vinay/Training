﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Double ER,Damount,Yamount;
            int option;
            Console.Write(" Enter exchange rate from Dollars to Yuan: ");
            ER = Convert.ToDouble(Console.ReadLine());
            Console.Write(" Enter 0 to convert from Dollars to Yuan or 1 for the vice versa: ");
            option = Convert.ToInt16(Console.ReadLine());

            if (option == 0)
            {
                Console.Write(" Enter the Dollar amount: ");
                Damount=Convert.ToDouble(Console.ReadLine());
                Yamount = Damount * ER;

                Console.WriteLine("{0:C} is {1:F1} yuan", Damount, Yamount);

            }
            else if (option == 1)
            {
                Console.Write(" Enter the Yuan amount: ");
                Yamount = Convert.ToDouble(Console.ReadLine());
                Damount = Yamount / ER;
                Console.WriteLine("{0:F1} yuan is {1:C} ", Yamount, Damount);

            }
            else
            {
                Console.WriteLine("Invalid Option ");
            }
            Console.Read();
        }
    }
}
