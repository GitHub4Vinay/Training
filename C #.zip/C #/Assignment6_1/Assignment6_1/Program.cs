﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 08 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[10];
            Console.WriteLine("Enter ten integers");
            for (int i = 0; i < 10; i++)
            {
                Console.Write("Enter integer: ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("\nIntegers in reverse order");
            for (int i = 9; i >= 0; i--)
            {
                Console.Write("{0} ", array[i]);
            }
            Console.Read();
        }
    }
}
