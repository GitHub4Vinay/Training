﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 23 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            Double Feets,Meters;
            Console.WriteLine("Enter value for Feets");
            Feets = Convert.ToDouble(Console.ReadLine());
            Meters =(Feets * 0.305);
           // Meters = String.Format("{0:F4}",Convert.ToString(Feets * 0.305));
            Console.Write(" {0} feet is Meters is {1:F4} ", Feets, Meters);
            Console.ReadLine();
            
        }
    }
}
