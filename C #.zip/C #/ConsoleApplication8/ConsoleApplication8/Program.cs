﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentence;
            Console.WriteLine("Please enter a sentence");
            sentence = Console.ReadLine();
            var words = sentence.Split();
            var sortedWords = (from word in words
                               orderby word.ToLower()
                               select word.ToLower()).Distinct();
            Console.WriteLine("Non duplicate words in alphabetical order are:");
            foreach (var word in sortedWords)
            {
                Console.WriteLine(word);
            }
            Console.Read();
        }
    }
}
