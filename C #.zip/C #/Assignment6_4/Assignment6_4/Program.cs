﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 08 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] array = new double[10];
            Console.WriteLine("Enter ten doubles.");
            for (int i = 0; i < 10; i++)
            {
                Console.Write("Enter double: ");
                array[i] = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine("\nMinimum: {0}", Min(array));
            Console.Read();
        }

        public static double Min(double[] array)
        {
            double min = array[0];
            for (int j = 1; j < 10; j++)
            {
                if (array[j] < min)
                {
                    min = array[j];
                }
            }
            return min;

        }
    }
}
