﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Double a, b, c, discriminant, r1,r2;

            Console.Write("Enter value for a: ");
            
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value for b: ");
            b = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter value for c: ");
            c = Convert.ToDouble(Console.ReadLine());

            discriminant = (Math.Pow(b,2) - (4 * a * c));
           // Console.WriteLine(discriminant);
            //Console.WriteLine((-b + Math.Sqrt(discriminant)));

            if (discriminant > 0)
            {
                r1 = (-b + Math.Sqrt(discriminant)) / 2 * a;
                r2 = (-b - Math.Sqrt(discriminant)) / 2 * a;
                Console.Write("The equation has two roots: {0:F5} and {1:F5}", r1,r2);
            }
            else if (discriminant == 0)
            {
                r1 = (-b + Math.Sqrt(discriminant)) / 2 * a;
                Console.Write("The equation has one root: {0:F5}", r1);

            }
            else
            {
                Console.Write("The equation has no roots");
            }

            Console.Read();

        }
    }
}
