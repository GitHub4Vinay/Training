﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 23 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            Double subtotal, tiprate,tip, total;
            Console.WriteLine("Enter the subtotal");
            subtotal = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the tip rate");
            tiprate = Convert.ToDouble(Console.ReadLine());
            tip = subtotal*(tiprate / 100);
            total = subtotal + tip;
           // Console.WriteLine("The tip is " + tip.ToString("C") + "and the total is " + total.ToString("C"));
            Console.WriteLine("The tip is {0:C} and the total is {1:C}" ,tip,total);
            Console.ReadLine();
           
        }
    }
}
