﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 7 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5_5
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int i = 0;
            M(i);
            Console.Read();
           
        }

            public static double M(int i)
            {
                double SUM = 0;
                Console.WriteLine("i\t\tM(i)");
                for (double j = 1; j <= 10; j++)
                {
                    SUM = SUM + (1 / j);
                    Console.WriteLine(j + "\t\t" + SUM);
                }

                return SUM;
            }

    }
}
