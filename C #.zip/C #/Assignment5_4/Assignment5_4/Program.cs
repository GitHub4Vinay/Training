﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 7 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5_4
{
    class Program
    {
        static void Main(string[] args)
        {
            
                Console.Write("Enter first integer: ");
                int x = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter second integer: ");
                int y = Convert.ToInt32(Console.ReadLine());
                Console.Write("GCD({0}, {1}) =  ", x, y);
                GreatestCommonDivisor(x, y);
                
                Console.Read();
        }
            public static int GreatestCommonDivisor(int m, int n)
            {
               
                
                if (m % n == 0)
                {
                    
                    Console.Write("{0}", n);
                    return n;
                }

                else
                {
                    GreatestCommonDivisor(n, m % n);
                    return n;
                }
            
    
        }
    }
}
