﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Kilograms\tPounds");
            for (int i = 1; i < 100; i += 2)
            {
                Console.WriteLine("{0}\t\t{1:F1}", i, i * 2.2);
            }
            Console.Read();
        }
    }
}
