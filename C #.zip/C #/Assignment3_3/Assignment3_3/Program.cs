﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.Write("Enter an integer: ");
            a = Convert.ToInt16(Console.ReadLine());

            if( (a%5==0) && (a%7== 0))
            {
                Console.WriteLine("{0} is divisible by either 5 and 7", a);

                Console.WriteLine("{0} is divisible by either 5 or 7", a);
            }
            else if ((a % 5 == 0) || (a % 7 == 0))
            {
                Console.WriteLine("{0} is divisible by either 5 or 7", a);

                Console.WriteLine("{0} is divisible by either 5 or 7, but not both", a);
            }
            else
            {
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}
