﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 07 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            PentagonalNumber(n);
            Console.Read();
        }

                
            public static int PentagonalNumber(int n)
            {
                
                Console.WriteLine("n\t\tPentagonalNumber(n)");
                for (int i = 1; i <= 100; i++)
                {
                    Console.WriteLine(i + "\t\t" + (i * ((3 * i) - 1)) / 2);
                }
                return n;
            }
    
        
    }
}
