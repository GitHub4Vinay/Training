﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double Total = 0;
            for (double i = 1; i < 98; i++)
            {
                Total += (i / (i + 2));
            }
            Console.WriteLine("Sum of the series 1/3+3/5+....+97/99 is: {0}", Total);

            Console.Read();
        }
    }
}
