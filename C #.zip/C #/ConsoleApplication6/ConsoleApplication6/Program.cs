﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 23 May 2016


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            Double investment, interestYr, total;
            int years;
            Console.WriteLine("Enter investment amount :");
            investment=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter annual interest rate as a percentage :");
            interestYr=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter number of years:");
            years = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine(Math.Pow((1 + (interestYr /100)), years ));
            total = investment * (Math.Pow((1 + ((interestYr /100)/12)), (years*12 )));
            //total = Math.Round(total, 2);
           // Console.WriteLine("Accumulated value is:" + total.ToString("C"));
           
            Console.WriteLine("Accumulated value is: {0:C}",total );
            Console.ReadLine();
                  }
    }
}
