﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 20 June 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_1
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Invoice Test");
            string partNumber, partDescription;
            int quantity;
            decimal price;
            Console.WriteLine("Please enter the part number:");
            partNumber = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Please enter the description:");
            partDescription = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Please enter the quantity:");
            quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter the price:");
            price = Convert.ToDecimal(Console.ReadLine());

            Invoice invoice = new Invoice(partNumber, partDescription, quantity, price);
            Console.WriteLine("\n\nYour Order:");
            Console.WriteLine("Part Number: {0}", invoice.Part_Number);
            Console.WriteLine("Part Description: {0}", invoice.Part_Description);
            Console.WriteLine("Quantity: {0}", invoice.Quantity);
            Console.WriteLine("Price: {0}", invoice.PriceOfItem);
            Console.WriteLine("Total: {0:C}", invoice.GetInvoiceAmount());
            Console.Read();

        }
        

    }
}
