﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_1
{
    class Invoice
    {
        public string Part_Number { get; set; }
        public string Part_Description { get; set; }
        private int quantity;
        private decimal priceOfItem;

        public Invoice(string part_Number, string part_Description, int quantity, decimal priceOfItem)
        {
            Part_Number = part_Number;
            Part_Description = part_Description;
            Quantity = quantity;
            PriceOfItem = priceOfItem;
        }
        public int Quantity
        {
            get
            {
                return quantity;
            }
            set
            {
                if (value > 0)
                    quantity = value;
                else
                    quantity = 1;
            }
        }

        public decimal PriceOfItem
        {
            get
            {
                return priceOfItem;
            }
            set
            {
                if (value > 0)
                    priceOfItem = value;
                else
                    priceOfItem = 1;
            }
        }

        public decimal GetInvoiceAmount()
        {
            return quantity * priceOfItem;
        }

    }
}
