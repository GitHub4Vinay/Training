﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class Program
    {
        static void Main(string[] args)
        {
            int output, userInput;
            userInput = 9;
            if (userInput == 8)
            {
                output = userInput * userInput;
            }
            else if (userInput > 8)
            {
                userInput--;
                output = userInput;
            }
            else
            {
                userInput++;
                output = userInput;
            }
            Console.WriteLine(output);


           
            Console.Read();
        }
    }
}
