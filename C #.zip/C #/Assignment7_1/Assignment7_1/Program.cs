﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 15 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7_1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int[] array = new int[100];
            Random RandomGenerator = new Random();
            for (int i = 0; i < 100; i++)
            {
                array[i] = RandomGenerator.Next(1, 101);
            }
            
            var sortedArray = from number in array
                              orderby number descending
                              select number;
            Console.WriteLine("Array elements in descending order :");
            foreach (var n in sortedArray)
            {
                Console.Write("{0} ", n);
            }
            var array50 = from number in array
                          
                          orderby number ascending
                          select number;
           
            Console.WriteLine("\n\nArray elements greater than or equal to 50 in ascending order :");

            foreach (var item in array50)
            {
                if (item >= 50)
                {
                    Console.Write("{0} ",item);
                }
            }
            var EvenNoArray = from number in array
                            where number % 2 == 0
                            orderby number ascending
                            select number;
            Console.WriteLine("\n\nArray elements that are Even in ascending order :");
            foreach (var n in EvenNoArray)
            {
                Console.Write("{0} ", n);
            }
            var DistinctNoArray = (from number in array
                                 orderby number ascending
                                 select number).Distinct();
            Console.WriteLine("\n\nArray elements that are Distinct in ascending order :");
            foreach (var n in DistinctNoArray)
            {
                Console.Write("{0} ", n);
            }
            Console.WriteLine("\n\nNumber of distinct array elements are :{0}", DistinctNoArray.Count());
            var PrimeNoArray = (from number in array
                              where IsPrime(number) == true
                              orderby number ascending
                              select number).Distinct();
            Console.WriteLine("\n\nArray elements that are distinct primary numbers in ascending order :");
            foreach (var n in PrimeNoArray)
            {
                Console.Write("{0} ", n);
            }
            Console.Read();
        }

        static bool IsPrime(int number)
        {
            int limit = (int)Math.Floor(Math.Sqrt(number));

            if (number == 1) return false;
            if (number == 2) return true;

            for (int i = 2; i <= limit; ++i)
            {
                if (number % i == 0) return false;
            }
            return true;
            
        }

        

    }
}
