﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods1
{
    class Program
    {
        static void Main(string[] args)
        {

            int x;
            x = 5;

            if (x < 10)
            {
                x--;
                Console.WriteLine(x);

                --x;
                Console.Write(x);
            }


          
            Console.Read();
        }
    }
}
