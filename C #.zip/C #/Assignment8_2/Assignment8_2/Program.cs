﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 20 June 2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Employee Test");
            Employee employee1 = new Employee("Vinay", "Kumar", (decimal)500000.567);
            Employee employee2 = new Employee("Ramesh", "Betha", (decimal)900000.128);

            Console.WriteLine("Employee-1 Firstname:{0}", employee1.First_Name);
            Console.WriteLine("Employee-1 Lastname:{0}", employee1.Last_Name);
            Console.WriteLine("Employee-1 Salary:{0:C}", employee1.Salary);

            Console.WriteLine("\nEmployee-2 Firstname:{0}", employee2.First_Name);
            Console.WriteLine("Employee-2 Lastname:{0}", employee2.Last_Name);
            Console.WriteLine("Employee-2 Salary:{0:C}", employee2.Salary);

            Console.WriteLine("\n\nAfter 10% Raise");
            employee1.Salary = employee1.Salary * (decimal)1.1;
            employee2.Salary = employee2.Salary * (decimal)1.1;
            Console.WriteLine("Employee-1 {0:F2} {1:F2}  Salary: {2:C}", employee1.First_Name, employee1.Last_Name, employee1.Salary);
            Console.WriteLine("Employee-2 {0:F2} {1:F2}  Salary: {2:C}", employee2.First_Name, employee2.Last_Name, employee2.Salary);
            Console.Read();

        }
    }
}
