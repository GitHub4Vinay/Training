﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 30 May 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int Num = 0, Pcount = 0, Ncount = 0;
            double Average = 0.0, Count = 0, Sum = 0.0;

            do
            {
                Console.Write("Enter an integer (or 0 to quit): ");
                Num = Convert.ToInt32(Console.ReadLine());
                Count++;
                if (Num > 0)
                {
                    Pcount++;
                }
                else if (Num < 0)
                {
                    Ncount++;
                }

                Sum += Num;
                
                Average = Sum / (Count - 1);
            }
            while (Num != 0);

            Console.WriteLine("Positives: {0}", Pcount);
            Console.WriteLine("Negatives: {0}", Ncount);
            Console.WriteLine("Sum: {0}", Sum);
            Console.WriteLine("Average: {0:F2}", Average);
            Console.Read();
        }
       
    }
}
