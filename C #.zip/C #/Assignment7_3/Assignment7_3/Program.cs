﻿// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 15 June 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7_3
{
    class Program
    {
        static void Main(string[] args)
        {
                char letter = ' ';
                List<Char> letters = new List<char>();
                Random rand = new Random();
                for (int i = 0; i <= 30; i++)
                {
                    letter = (char)rand.Next(65, 91);
                    letters.Add(letter);
                }
                Console.WriteLine("Random Letters  :");
                foreach (var x  in letters)
                    Console.Write("{0} ",x);

                var Q1 = from letr in letters
                             orderby letr  ascending
                             select letr;
                Console.WriteLine("\n\nLetters list in Ascending order :");
                foreach (var x in Q1)
                    Console.Write("{0} ",x);

                var Q2 = from letr in letters
                             orderby letr descending
                             select letr;
                Console.WriteLine("\n\nLetters list in Descending order :");
                foreach (var x in Q2)
                    Console.Write("{0} ",x);

                var Q3 = (from letr in letters
                              orderby letr ascending
                              select letr).Distinct();
                Console.WriteLine("\n\nLetters list in Ascending order without duplicates :");
                foreach (var x in Q3)
                    Console.Write("{0} ",x);
                Console.Read();
           } 
   
    }
}
