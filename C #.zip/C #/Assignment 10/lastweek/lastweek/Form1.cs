﻿
// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 24 June 2016
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lastweek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random generator = new Random();
            int count = Convert.ToInt32( numericUpDown1.Value);
            for (int i = 0; i < count; i++)
            {
                Button newButton = new Button();
                newButton.Location = new Point(generator.Next(500),generator.Next(400));
                newButton.BackColor = Color.FromArgb(generator.Next(256), generator.Next(256), generator.Next(256));
                this.Controls.Add(newButton);
            }
        }
    }
}
