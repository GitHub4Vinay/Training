﻿
// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 24 June 2016
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovingImage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

 

      

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                pictureBox1.Top = pictureBox1.Top - 5;
            }
            else if (e.KeyCode == Keys.Down)
            {
                pictureBox1.Top = pictureBox1.Top +5;
            }
            else if (e.KeyCode == Keys.Right)
            {
                pictureBox1.Left = pictureBox1.Left + 5;
            }
            else if (e.KeyCode == Keys.Left)
            {
                pictureBox1.Left = pictureBox1.Left - 5;
            }

        }
    }
}
