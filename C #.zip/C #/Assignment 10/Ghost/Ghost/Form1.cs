﻿
// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 24 June 2016
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ghost
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // Decrement
                if (this.Opacity >= 0.2)
                {
                    this.Opacity -= 0.1;
                }
            }
            else if (e.Button == MouseButtons.Right)
            {
                //Increment
                this.Opacity += 0.1;
            }

        }
    }
}
