﻿
// Vinay Kumar Vangimalla
// CS 5110 MW 10 AM Summer 2016
// 24 June 2016
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomColors
{
    public partial class Form1 : Form
    {
        private Random generator;
        public Form1()
        {
            InitializeComponent();
            generator = new Random();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(generator.Next(256), generator.Next(256), generator.Next(256));
        }
    }
}
