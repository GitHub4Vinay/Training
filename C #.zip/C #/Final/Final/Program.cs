﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[5];
            array[0] = 100;
            array[array.Length - 1] = 99;
            array[1 + 1] = 5;
            array[2]++;
            array[1]++;
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("{0} {1}",Convert.ToString(i), array[i]);
            }
            

            int[] a = { 1, 2, 3, 4, 5 };
            for (int i = a.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(a[i] + " ");
            }

            int[] x = { 1, 2, 3, 4, 5 };
            int y = 0;
            for (int i = 0; i < x.Length; i++)
            {
                y += x[i];
            }
            Console.WriteLine(y);
            int[,] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            matrix[0, 0]++;
            matrix[0, 2]--;
            matrix[1, 1] = 2;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

            int[,] matrix1 = { { 2, 3}, {0, 4},{0,7},{0,9}};
            Console.WriteLine(matrix1.GetLength(1));
            //GetLength(1) -- No of Colum
            //GetLength(0) -- No of rows

            int[,] b = { { 1, 2 }, { 3, 4 }, { 5, 6 } };
            int z = 0;
            for (int i = 0; i < b.GetLength(0); i++)
            {
                z += b[i, 0];

                Console.WriteLine(z);
            }


            int[] numbers = { 1, 1, 1, 2, 3, 7, 7, 7, 9, 9 };
            var query =
            from n in numbers
            where n > 5
            select n;
            foreach (var q in query.Distinct())
            {
                Console.WriteLine(" {0}", q);
            }

            int v = 5;
            v++;
            Console.WriteLine(v--);
            Console.WriteLine(v--);
            Console.Read();
                
        }
    }
}
